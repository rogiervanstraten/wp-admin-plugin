<?php
/**
 * Author: Baldadig
 * URL: http://baldadig.nl/
 * Description: 
 * Version: 1.0.0
 */

require_once '_clean_dashboard.php';

require_once '_clean_head.php';

require_once '_functions.php';

require_once '_admin_bar.php';

require_once '_admin_login.php';

require_once '_admin_dashboard.php';

require_once '_admin_footer.php';
